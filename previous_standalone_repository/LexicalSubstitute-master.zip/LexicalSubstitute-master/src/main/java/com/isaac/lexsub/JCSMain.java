package com.isaac.lexsub;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isaac.evaluation.GAPScore;
import com.isaac.representation.ContextInstance;
import com.isaac.representation.CsEmbeddingInferrer;
import com.isaac.utils.FileUtils;
import com.isaac.utils.Text2Binary;
import com.isaac.utils.Utils;

public class JCSMain {

	public static void main(String[] args) {
		// pre-process the embedding files
		String wordEmbPath = "<Your Embedding Path>";
		Text2Binary.convert(wordEmbPath);
		String contextEmbPath = "<Your Embedding Path>";
		Text2Binary.convert(contextEmbPath);
		System.out.println("Convert embeddings from text file to binary file");
		// perform the lexical substitution evaluation
		Configuration config = new Configuration()
				.setInferrer("emb")
				.setVocabFile("src/main/resources/datasets/ukwac.vocab.lower.min100")
				.setTestFile("src/main/resources/datasets/lst_all.preprocessed.lemma")
				.setTestFileConll("src/main/resources/datasets/lst_all.conll.lemma")
				.setCandidatesFile("src/main/resources/datasets/lst.gold.candidates.lemma")
				.setEmbeddingPath(wordEmbPath)
				.setEmbeddingPathC(contextEmbPath)
				.setContextMath("mult")
				.setDebug(true)
				.setResultsFile("src/main/resources/results");
		run(config);
		// compute the candidate ranking GAP score
		GAPScore.evaluate("src/main/resources/datasets/lst_all.gold.lemma",
				"src/main/resources/results.ranked",
				"src/main/resources/gapscore", "no-mwe", null);
		// compute the OOT and BEST substitute prediction scores -- TODO
	}
	
	public static void run(Configuration config) {
		if (config.inferrer.equals("emb")) {
			CsEmbeddingInferrer inferrer = new CsEmbeddingInferrer(config.vocabFile, config.ignoreTarget, 
					config.contextMath, config.embeddingPath, config.embeddingPathC, config.testFileConll, config.bow, 
					config.topGenerated);
			System.out.println("Using CsEmbeddingInferrer");
			runTestByCsEmbeddingInferrer(inferrer, config);
		} else if (config.inferrer.equals("lstm")) {
			// TODO -- Context2VecInferrer
			System.out.println("Using Context2VecInferrer");
		} else {
			throw new IllegalArgumentException("Unknown inferrer type: " + config.inferrer);
		}
		System.out.println("Finished!!!");
	}
	
	public static void runTestByCsEmbeddingInferrer(CsEmbeddingInferrer inferrer, Configuration config) {
		Map<String, List<String>> target2Candidates = new HashMap<>();
		if (config.candidatesFile != null) {
			target2Candidates = FileUtils.readCandidates(config.candidatesFile);
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader(config.testFile));
			BufferedWriter writer = new BufferedWriter(new FileWriter(config.resultsFile));
			BufferedWriter writerRanked = new BufferedWriter(new FileWriter(config.resultsFile + ".ranked"));
			BufferedWriter writerGeneratedOot = new BufferedWriter(new FileWriter(config.resultsFile + 
					".generated.oot"));
			BufferedWriter writerGeneratedBest = new BufferedWriter(new FileWriter(config.resultsFile + 
					".generated.best"));
			int lines = 0;
			String contextLine;
			while ((contextLine = reader.readLine()) != null) {
				ContextInstance lstInstance = new ContextInstance(contextLine, config.noPos);
				lines++;
				if (config.debug)
					writer.write("\nTest context:\n***************\n");
				writer.write(lstInstance.decorateContext());
				List<Map.Entry<String, Float>> resultVec = inferrer.findInferred(lstInstance);
				Map<String, Float> generatedResults = inferrer.generateInferred(resultVec, lstInstance.getTarget(), 
						lstInstance.getTargetLemma());
				writer.write("\nGenerated lemmatized results\n***************\n");
				writer.write("GENERATED\t" + 
						String.join(" ", lstInstance.getFullTargetKey(), String.valueOf(lstInstance.getTargetId()))
						+ " ::: " + 
						Utils.vec2StrGenerated(new ArrayList<>(generatedResults.entrySet()), config.topGenerated)
						+ "\n");
				writerGeneratedOot.write(
						String.join(" ", lstInstance.getFullTargetKey(), String.valueOf(lstInstance.getTargetId()))
						+ " ::: " + 
						Utils.vec2StrGenerated(new ArrayList<>(generatedResults.entrySet()), config.topGenerated)
						+ "\n");
				writerGeneratedBest.write(
						String.join(" ", lstInstance.getFullTargetKey(), String.valueOf(lstInstance.getTargetId()))
						+ " ::: " + 
						Utils.vec2StrGenerated(new ArrayList<>(generatedResults.entrySet()), 1) + "\n");
				Map<String, Float> filteredResults = inferrer.filterInferred(resultVec, 
						target2Candidates.get(lstInstance.getTargetKey()));
				writer.write("\nFiltered results\n***************\n");
				writer.write("RANKED\t" + 
						String.join(" ", lstInstance.getFullTargetKey(), String.valueOf(lstInstance.getTargetId()))
						+ "\t" + 
						Utils.vec2Str(new ArrayList<>(filteredResults.entrySet()), filteredResults.size()) + "\n");
				writerRanked.write("RANKED\t" + 
						String.join(" ", lstInstance.getFullTargetKey(), String.valueOf(lstInstance.getTargetId()))
						+ "\t" + 
						Utils.vec2Str(new ArrayList<>(filteredResults.entrySet()), filteredResults.size()) + "\n");
				if (lines % 10 == 0)
					System.out.println("read " + lines + " lines!");
			}
			reader.close();
			writer.close();
			writerRanked.close();
			writerGeneratedOot.close();
			writerGeneratedBest.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
