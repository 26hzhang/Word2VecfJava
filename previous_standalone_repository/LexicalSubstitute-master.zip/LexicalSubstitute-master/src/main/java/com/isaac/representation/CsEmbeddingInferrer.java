package com.isaac.representation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.ops.transforms.Transforms;

import com.isaac.utils.FileUtils;
import com.isaac.utils.Utils;

public class CsEmbeddingInferrer extends CsInferrer {
	
	private String contextMath;
	private Embedding wordVecs;
	private Embedding contextVecs;
	private boolean useStopWords = false;
	private boolean ignoreTarget;
	private int windowSize;
	private List<List<Token>> sents;
	private int topInferences2Analyze;
	private Map<String, Integer> w2Counts;
	private Iterator<List<Token>> iter;
	
	public CsEmbeddingInferrer(String vocabfile, boolean ignoreTarget, String contextMath, String wordPath, 
			String contextPath, String conllFilename, int windowSize, int topInferences2Analyze) {
		this.contextMath = contextMath;
		this.ignoreTarget = ignoreTarget;
		this.windowSize = windowSize;
		this.topInferences2Analyze = topInferences2Analyze;
		this.w2Counts = FileUtils.loadVocabularyCounts(vocabfile, -1);
		this.sents = FileUtils.readConll(conllFilename, true);
		this.wordVecs = new Embedding(wordPath, false);
		this.contextVecs = new Embedding(contextPath, false);
		this.iter = this.sents.iterator();
	}
	
	public INDArray Represent(String target, List<String> deps, boolean avgFlag) {
		INDArray targetVec = wordVecs.Represent(target);
		INDArray depVec = contextVecs.Zeros();
		int depsFound = 0;
		for (String dep : deps) {
			if (!contextVecs.Contains(dep))
				continue;
			depsFound++;
			depVec.addi(contextVecs.Represent(dep).dup()); // each element add with each other
		}
		INDArray retVec = targetVec.dup();
		if (depsFound > 0) {
			if (avgFlag)
				depVec.divi(Nd4j.scalar(depsFound));
			retVec.addi(depVec);
		}
		double norm = Math.pow(retVec.mmul(retVec.transpose()).getDouble(0), 0.5);
		if (norm != 0.0)
			retVec.divi(Nd4j.scalar(norm));
		return retVec;
	}
	
	public List<Map.Entry<String, Float>> Mult(String target, List<String> deps, boolean geoMeanFlag) {
		INDArray targetVec = wordVecs.Represent(target);
		INDArray scores = wordVecs.PosScores(targetVec);
		for (String dep : deps) {
			if (!contextVecs.Contains(dep))
				continue;
			INDArray depVec = contextVecs.Represent(dep);
			INDArray multScores = wordVecs.PosScores(depVec);
			if (geoMeanFlag)
				multScores = Transforms.pow(multScores, 1.0 / deps.size());
			scores.muli(multScores);
		}
		return wordVecs.TopScores(scores, -1);
	}
	
	public List<String> extractContexts(ContextInstance lstInstance) {
		List<String> contexts;
		if (this.windowSize < 0) {
			List<Token> curSent = iter.next();
			int curSentTargetInd = lstInstance.targetInd + 1;
			while (curSentTargetInd < curSent.size() && !curSent.get(curSentTargetInd).form.equals(lstInstance.target)) {
				System.out.println("Target word form mismatch in target id " + lstInstance.targetId + ": " + 
						curSent.get(curSentTargetInd).form + " != " + lstInstance.target + "  Checking next word.\n");
				curSentTargetInd++;
			}
			if (curSentTargetInd == curSent.size()) {
				System.out.println("Start looking backwards.\n");
				curSentTargetInd = lstInstance.targetInd;
				while (curSentTargetInd > 0 && !curSent.get(curSentTargetInd).form.equals(lstInstance.target)) {
					System.out.println("Target word form mismatch in target id " + lstInstance.targetId + ": " + 
							curSent.get(curSentTargetInd).form + " != " + lstInstance.target + 
							"  Checking next word.\n");
					curSentTargetInd--;
				}
			}
			if (curSentTargetInd == 0) {
				System.out.println("ERROR: Couldn't find a match for target.");
				curSentTargetInd = lstInstance.targetInd + 1;;
			}
			contexts = Utils.getDeps(curSent, curSentTargetInd);
		} else {
			contexts = lstInstance.getNeighbors(this.windowSize);
		}
		return contexts;
	}
	
	public List<Map.Entry<String, Float>> findInferred(ContextInstance lstInstance) {
		List<String> tmpContexts = extractContexts(lstInstance);
		List<String> contexts = new ArrayList<>();
		for (String context : tmpContexts) {
			if (contextVecs.Contains(context))
				contexts.add(context);
		}
		String target;
		if (this.ignoreTarget) {
			target = null;
		} else {
			if (wordVecs.Contains(lstInstance.target)) {
				target = lstInstance.target;
			} else {
				if (wordVecs.Contains(lstInstance.targetLemma))
					target = lstInstance.targetLemma;
				else
					return null;
			}
		}
		List<Map.Entry<String, Float>> resultVec;
		if (this.contextMath.equals("add")) {
			INDArray csRep = Represent(target, contexts, false);
			resultVec = wordVecs.ClosestVec(csRep, -1);
		} else if (this.contextMath.equals("avg")) {
			INDArray csRep = Represent(target, contexts, true);
			resultVec = wordVecs.ClosestVec(csRep, -1);
		} else if (this.contextMath.equals("mult")) {
			resultVec = Mult(target, contexts, false);
		} else if (this.contextMath.equals("geomean")) {
			resultVec = Mult(target, contexts, true);
		} else if (this.contextMath.equals("none") && !this.ignoreTarget) {
			resultVec = wordVecs.Closest(target, -1);
		} else {
			throw new IllegalArgumentException("Unknown context math: " + this.contextMath);
		}
		if (resultVec.isEmpty()) {
			System.out.println("Top most similar embeddings: " + " contexts: None\n");
		} else {
			System.out.println("Top most similar embeddings: " + 
					Utils.vec2Str(resultVec, this.topInferences2Analyze) + "\n");
		}
		return resultVec;
	}

	public String getContextMath() {
		return contextMath;
	}

	public void setContextMath(String contextMath) {
		this.contextMath = contextMath;
	}

	public Embedding getWordVecs() {
		return wordVecs;
	}

	public void setWordVecs(Embedding wordVecs) {
		this.wordVecs = wordVecs;
	}

	public Embedding getContextVecs() {
		return contextVecs;
	}

	public void setContextVecs(Embedding contextVecs) {
		this.contextVecs = contextVecs;
	}

	public boolean isUseStopWords() {
		return useStopWords;
	}

	public void setUseStopWords(boolean useStopWords) {
		this.useStopWords = useStopWords;
	}

	public boolean isIgnoreTarget() {
		return ignoreTarget;
	}

	public void setIgnoreTarget(boolean ignoreTarget) {
		this.ignoreTarget = ignoreTarget;
	}

	public int getWindowSize() {
		return windowSize;
	}

	public void setWindowSize(int windowSize) {
		this.windowSize = windowSize;
	}

	public List<List<Token>> getSents() {
		return sents;
	}

	public void setSents(List<List<Token>> sents) {
		this.sents = sents;
	}

	public int getTopInferences2Analyze() {
		return topInferences2Analyze;
	}

	public void setTopInferences2Analyze(int topInferences2Analyze) {
		this.topInferences2Analyze = topInferences2Analyze;
	}

	public Map<String, Integer> getW2Counts() {
		return w2Counts;
	}

	public void setW2Counts(Map<String, Integer> w2Counts) {
		this.w2Counts = w2Counts;
	}

}
