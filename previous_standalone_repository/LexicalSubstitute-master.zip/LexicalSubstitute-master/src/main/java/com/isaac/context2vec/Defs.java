package com.isaac.context2vec;

public class Defs {
	
	static class Toks {
		
		public static final int UNK = 0;
		public static final int BOS = 1; // beginning of sentence
		public static final int EOS = 2; // end of sentence
	}
	
	public static final int NEGATIVE_SAMPLING_NUM = 10;
	public static final int IN_TO_OUT_UNITS_RATIO = 2;
	public static final String SENT_COUNTS_FILENAME = "s_counts";
	public static final String WORD_COUNTS_FILENAME = "w_counts";
	public static final String TOTAL_COUNTS_FILENAME = "totals";

}
