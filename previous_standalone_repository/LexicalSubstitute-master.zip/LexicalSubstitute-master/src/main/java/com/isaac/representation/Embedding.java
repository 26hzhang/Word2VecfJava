package com.isaac.representation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;

import com.isaac.utils.FileUtils;


public class Embedding {
	/** words vocabulary */
	public List<String> words;
	/** words vectors, each row with dimension of layerSize */
	public INDArray matrix;
	/** dimension of each word vector */
	public int layerSize;
	/** the vectors are normalized */
	public boolean normalized;

	public Embedding() {
	}

	public Embedding(String path, boolean normalize) {
		EmbMode mode = FileUtils.readEmbeddingFromBinary(path);
		this.words = mode.getWords();
		this.matrix = Nd4j.create(mode.getVectors());
		if (normalize)
			this.matrix = this.Normalize(matrix);
		this.normalized = normalize;
		this.layerSize = matrix.columns();
	}

	public Embedding(List<String> words, INDArray matrix, boolean normalize) {
		this.words = words;
		if (normalize)
			this.matrix = this.Normalize(matrix);
		else
			this.matrix = matrix;
		this.layerSize = this.matrix.columns();
		this.normalized = normalize;
	}

	public INDArray Zeros() {
		return Nd4j.zeros(1, this.layerSize);
	}

	public INDArray Ones() {
		return Nd4j.ones(1, this.layerSize);
	}

	public int vocabSize() {
		return this.words.size();
	}

	public int Dimension() {
		return this.layerSize;
	}

	public boolean Contains(String str) {
		return words.contains(str);
	}

	protected INDArray Normalize(INDArray array) {
		INDArray norm = array.norm2(1);
		for (int i = 0; i < norm.size(0); i++)
			for (int j = 0; j < norm.size(1); j++)
				if (norm.getFloat(i) == 0)
					norm.put(i, j, 1.0);
		return array.diviRowVector(norm);
	}

	public INDArray Represent(String str) {
		if (this.words.contains(str))
			return this.matrix.getRow(words.indexOf(str));
		else
			return this.Zeros();
	}

	public INDArray Scores(INDArray vector) {
		return this.matrix.mmul(vector.transpose());
	}

	public INDArray PosScores(INDArray vector) {
		return this.matrix.mmul(vector.transpose()).add(1).div(2);
	}

	public INDArray PosScores2(INDArray vector) {
		INDArray scores = this.matrix.mmul(vector.transpose());
		for (int i = 0; i < scores.size(0); i++)
			for (int j = 0; j < scores.size(1); j++)
				if (scores.getFloat(i, j) < 0.0)
					scores.put(i, j, 0.0);
		return scores;
	}

	public List<Map.Entry<String, Float>> TopScores(INDArray scores) {
		int num = 10;
		Map<String, Float> map = new HashMap<String, Float>(1000000, 1.0f);
		for (int i = 0; i < words.size(); i++)
			map.put(words.get(i), scores.getFloat(i));
		List<Map.Entry<String, Float>> list = new ArrayList<Map.Entry<String, Float>>(map.entrySet());
		list = list.stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder())).collect(Collectors.toList());
		return list.subList(0, num);
	}

	public List<Map.Entry<String, Float>> TopScores(INDArray scores, int num) {
		if (num < 0)
			num = scores.size(0) > scores.size(1) ? scores.size(0) : scores.size(1);
		else if (num == 0)
			num = 10;
		Map<String, Float> map = new HashMap<String, Float>(1000000, 1.0f);
		for (int i = 0; i < words.size(); i++)
			map.put(words.get(i), scores.getFloat(i));
		List<Map.Entry<String, Float>> list = new ArrayList<Map.Entry<String, Float>>(map.entrySet());
		list = list.stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder())).collect(Collectors.toList());
		return list.subList(0, num);
	}

	public List<Map.Entry<String, Float>> Closest(String str) {
		INDArray scores = this.matrix.mmul(this.Represent(str).transpose());
		List<Map.Entry<String, Float>> result = this.TopScores(scores);
		return result;
	}

	public List<Map.Entry<String, Float>> Closest(String str, int num) {
		INDArray scores = this.matrix.mmul(this.Represent(str).transpose());
		List<Map.Entry<String, Float>> result = this.TopScores(scores, num);
		return result;
	}

	public List<Map.Entry<String, Float>> ClosestVec(INDArray vector) {
		INDArray scores = this.matrix.mmul(vector.transpose());
		List<Map.Entry<String, Float>> result = this.TopScores(scores);
		return result;
	}

	public List<Map.Entry<String, Float>> ClosestVec(INDArray vector, int num) {
		INDArray scores = this.matrix.mmul(vector.transpose());
		List<Map.Entry<String, Float>> result = this.TopScores(scores, num);
		return result;
	}

	public float Similarity(String word1, String word2) {
		return this.Represent(word1).mmul(this.Represent(word2).transpose()).getFloat(0);
	}

}
