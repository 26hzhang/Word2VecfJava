package com.isaac.representation;

public class Context2VecInferrer extends CsInferrer {
	
	// TODO
	
	public Context2VecInferrer() {
		super();
	}
}
