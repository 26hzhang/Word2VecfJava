package com.isaac.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Text2Binary {
	
	public static void convert(String filename) {
		List<Map.Entry<String, float[]>> list = 
				new ArrayList<>(readFromTextToMap(filename).entrySet());
		list = list.stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toList());
		List<String> words = new ArrayList<>();
		List<float[]> matList = new ArrayList<>();
		Iterator<Map.Entry<String, float[]>> it = list.iterator();
		while (it.hasNext()) {
			Map.Entry<String, float[]> entry = it.next();
			words.add(entry.getKey());
			matList.add(entry.getValue());
		}
		float[][] matrix = matList.toArray(new float[0][]);
		saveVocabulary(filename + ".vocab", words);
		saveVectors(filename + ".matrix", matrix);
	}
	
	private static Map<String, float[]> readFromTextToMap(String filename) {
		Map<String, float[]> map = new HashMap<>();
		try {
			File file = new File(filename);
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String line = br.readLine();
			@SuppressWarnings("unused")
			int vocabSize = Integer.parseInt(line.split(" ")[0]);
			int layerSize = Integer.parseInt(line.split(" ")[1]);
			String[] values;
			while ((line = br.readLine()) != null) {
				values = line.split(" ");
				String word = values[0];
				float[] matrix = new float[layerSize];
				for (int i = 1; i < values.length; i++)
					matrix[i - 1] = Float.parseFloat(values[i]);
				map.put(word, matrix);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}
	
	public static void saveVocabulary(String filename, List<String> words) {
		File wordFile = new File(filename + ".vocab");
		try {
			if (wordFile.exists())
				wordFile.delete();
			wordFile.createNewFile();
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(wordFile)));
			// Write words to file
			for (int i = 0; i < words.size(); i++) {
				bw.write(words.get(i) + "\n");
				bw.flush();
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void saveVectors(String filename, float[][] matrix) {
		int vocabSize = matrix.length;
		int layerSize = matrix[0].length;
		File matrixFile = new File(filename + ".matrix");
		if (matrixFile.exists())
			matrixFile.delete();
		try {
			matrixFile.createNewFile();
			// Write vocabSize and layerSize to file
			FileOutputStream fos = new FileOutputStream(matrixFile);
			ByteBuffer buffer = ByteBuffer.allocate(4 * 2);
			buffer.clear();
			buffer.putFloat(vocabSize).putFloat(layerSize);
			fos.write(buffer.array());
			fos.flush();
			// Write matrix to file
			buffer = ByteBuffer.allocate(4 * layerSize);
			for (int i = 0; i < vocabSize; i++) {
				buffer.clear();
				for (int j = 0; j < layerSize; j++) {
					buffer.putFloat(matrix[i][j]);
				}
				fos.write(buffer.array());
			}
			fos.flush();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
