package com.isaac.representation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.isaac.utils.Utils;

public class CsInferrer {
	
	private final List<String> defaultGeneratedResults = new ArrayList<>(Arrays.asList("time", "people", "information",
			"work", "first", "like", "year", "make", "day", "service"));
	public final Pattern pattern = Pattern.compile("^[a-zA-Z]+$");
	
	public Map<String, Float> generateInferred(List<Map.Entry<String, Float>> resultVec, String targetWord, String targetLemma) {
		Map<String, Float> generatedResults = new HashMap<>();
		float minWeight = Float.MIN_VALUE;
		if (!resultVec.isEmpty()) {
			for (Map.Entry<String, Float> entry : resultVec) {
				if (pattern.matcher(entry.getKey()).matches()) { // make sure this is not junk
					String lemma = Utils.lemmatize(entry.getKey());
					float weight = entry.getValue();
					if (!entry.getKey().equals(targetWord) && !lemma.equals(targetLemma)) {
						if (generatedResults.containsKey(lemma))
							weight = Math.max(weight, generatedResults.get(lemma));
						generatedResults.put(lemma, weight);
						if (minWeight == Float.MIN_VALUE)
							minWeight = weight;
						else
							minWeight = Math.min(minWeight, weight);
					}
				}
			}
		}
		if (minWeight == Float.MIN_VALUE) {
			minWeight = 0.0f;
		}
		float i = 0.0f;
		for (String lemma : defaultGeneratedResults) {
			if (generatedResults.size() >= defaultGeneratedResults.size())
				break;
			i -= 1.0f;
			generatedResults.put(lemma, minWeight + i);
		}
		return generatedResults;
	}
	
	public Map<String, Float> filterInferred(List<Map.Entry<String, Float>> resultVec, List<String> candidates) {
		Map<String, Float> filteredResults = new HashMap<>();
		Set<String> candidatesFound = new LinkedHashSet<>();
		if (!resultVec.isEmpty()) {
			for (Map.Entry<String, Float> entry : resultVec) {
				String word = entry.getKey();
				String lemma = Utils.lemmatize(word);
				float weight = entry.getValue();
				if (candidates.contains(lemma)) {
					candidatesFound.add(lemma);
					float bestLastWeight = Float.MIN_VALUE;
					if (filteredResults.containsKey(lemma))
						bestLastWeight = filteredResults.get(lemma);
					if (bestLastWeight == Float.MIN_VALUE || weight > bestLastWeight)
						filteredResults.put(lemma, weight);
				}
				if (candidates.contains(title(lemma))) {
					candidatesFound.add(title(lemma));
					float bestLastWeight = Float.MIN_VALUE;
					if (filteredResults.containsKey(title(lemma)))
						bestLastWeight = filteredResults.get(title(lemma));
					if (bestLastWeight == Float.MIN_VALUE || weight > bestLastWeight)
						filteredResults.put(title(lemma), weight);
				}
				if (candidates.contains(word)) {
					candidatesFound.add(word);
					float bestLastWeight = Float.MIN_VALUE;
					if (filteredResults.containsKey(word))
						bestLastWeight = filteredResults.get(word);
					if (bestLastWeight == Float.MIN_VALUE || weight > bestLastWeight)
						filteredResults.put(word, weight);
				}
				if (candidates.contains(title(word))) {
					candidatesFound.add(title(word));
					float bestLastWeight = Float.MIN_VALUE;
					if (filteredResults.containsKey(title(word)))
						bestLastWeight = filteredResults.get(title(word));
					if (bestLastWeight == Float.MIN_VALUE || weight > bestLastWeight)
						filteredResults.put(title(word), weight);
				}
			}
		}
		return filteredResults;
	}
	
	private String title(String str) {
		return str.substring(0, 1).toUpperCase() + str.substring(1);
	}
	
}
