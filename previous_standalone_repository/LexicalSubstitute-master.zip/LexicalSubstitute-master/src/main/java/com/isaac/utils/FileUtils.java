package com.isaac.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.isaac.representation.EmbMode;
import com.isaac.representation.Token;

public class FileUtils {
	
	private final static long ONE_GB = 1024 * 1024 * 1024;
	
	public static Map<String, List<String>> readCandidates(String candidatesFilePath) {
		Map<String, List<String>> candidatesMap = new LinkedHashMap<>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(candidatesFilePath));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] segments = line.split("::");
				String target = segments[0];
				List<String> candidates = new ArrayList<>(Arrays.asList(segments[1].split(";")));
				candidatesMap.put(target, candidates);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return candidatesMap;
	}
	
	public static Map<String, Integer> loadVocabularyCounts(String vocabFilePath, double factor) {
		if (factor < 0)
			factor = 1.0;
		Map<String, Integer> counts = new LinkedHashMap<>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(vocabFilePath));
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.isEmpty())
					continue;
				String[] tokens = line.trim().split("\t");
				String word = tokens[0].trim();
				int count = Integer.parseInt(tokens[1].trim());
				if (factor != 1.0)          
                    count = (int) (count * factor);
				counts.put(word, count);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return counts;
	}
	
	public static List<List<Token>> readConll(String conllFilePath, boolean lower) {
		List<List<Token>> sents = new ArrayList<>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(conllFilePath));
			List<Token> sent = new ArrayList<>();
			sent.add(new Token());
			String line;
			while ((line = reader.readLine()) != null) {
				line = line.trim();
				if (line.length() > 0) {
					if (lower)
						line = line.toLowerCase();
					String[] words = line.split("\t");
					Token token = new Token(words);
					sent.add(token);
				} else {
					if (sent.size() > 1)
						sents.add(sent);
					sent = new ArrayList<>();
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sents;
	}
	
	public static EmbMode readEmbeddingFromBinary(String filename) {
		List<String> words = new ArrayList<String>();
		float[][] matrix = null;
		try {
			// load vocabulary
			BufferedReader reader = new BufferedReader(new FileReader(filename + ".vocab"));
			String line;
			while ((line = reader.readLine()) != null)
				words.add(line.trim());
			reader.close();
			// load vectors
			FileInputStream fis = new FileInputStream(new File(filename + ".matrix"));
			FileChannel channel = fis.getChannel();
			MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, Math.min(channel.size(), 
					Integer.MAX_VALUE));
			final float[] sizes = new float[2]; // load vocabSize and layerSize
			final FloatBuffer sizeBuffer = buffer.asFloatBuffer();
			sizeBuffer.get(sizes);
			buffer.position(buffer.position() + 4 * 2);
			int vocabSize = (int) sizes[0];
			int layerSize = (int) sizes[1];
			matrix = new float[vocabSize][layerSize]; // load float vectors from matrix file
			int bufferCount = 1;
			final float[] floats = new float[layerSize];
			for (int lineno = 0; lineno < vocabSize; lineno++) {
				final FloatBuffer floatBuffer = buffer.asFloatBuffer();
				floatBuffer.get(floats);
				for (int i = 0; i < floats.length; ++i) {
					matrix[lineno][i] = floats[i];
				}
				buffer.position(buffer.position() + 4 * layerSize);
				if (buffer.position() > ONE_GB) { // reallocate
					final int newPosition = (int) (buffer.position() - ONE_GB);
					final long size = Math.min(channel.size() - ONE_GB * bufferCount, Integer.MAX_VALUE);
					buffer = channel.map(FileChannel.MapMode.READ_ONLY, ONE_GB * bufferCount, size);
					buffer.position(newPosition);
					bufferCount += 1;
				}
			}
			channel.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new EmbMode(matrix[0].length, words, matrix);
	}

}
