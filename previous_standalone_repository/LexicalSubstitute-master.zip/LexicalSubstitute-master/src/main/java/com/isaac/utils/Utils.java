package com.isaac.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import com.isaac.representation.Token;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.LemmaAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;

public class Utils {
	
	@SuppressWarnings("serial")
	public static final Map<String, String> fromLstPos = new HashMap<String, String>() {{
			put("r", "R");
			put("j", "J");
			put("a", "J");
			put("v", "V");
			put("n", "N");
		}};
	
	private static final StanfordCoreNLP pipeline;
	static {
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, pos, lemma");
		pipeline = new StanfordCoreNLP(props);
	}
	
	public static String lemmatize(String word) {
		String lemmas = "";
		// create an empty Annotation just with the given text
		Annotation annotation = new Annotation(word);
		// run all Annotators on this string
		pipeline.annotate(annotation);
		// Iterate over all of the sentences found
		List<CoreMap> sentences = annotation.get(SentencesAnnotation.class);
		for (CoreMap sentence : sentences) {
			// Iterate over all tokens in a sentence
			for (CoreLabel token : sentence.get(TokensAnnotation.class)) {
				// Retrieve and add the lemma for each word into the list of lemmas
				//lemmas.add(token.get(LemmaAnnotation.class));
				lemmas += token.get(LemmaAnnotation.class) + " ";
			}
		}
		return lemmas.trim();
	}
	
	public static List<String> getDeps(List<Token> sent, int targetInd) {
		List<String> deps = new ArrayList<>();
		for (Token wordLine : sent) {
			Token parentLine = sent.get(wordLine.getHead());
			if (wordLine.getDeptype().equals("preps"))
				continue;
			String relation;
			String head;
			if (wordLine.getDeptype().equals("pobj") && parentLine.getId() != 0) {
				Token grandparentLine = sent.get(parentLine.getHead());
				if (grandparentLine.getId() != targetInd && wordLine.getId() != targetInd)
	                continue;
				relation = String.join(":", parentLine.getDeptype(), parentLine.getForm());
				head = grandparentLine.getForm();
			} else {
				if (parentLine.getId() != targetInd && wordLine.getId() != targetInd)
					continue;
				head = parentLine.getForm();
			    relation = wordLine.getDeptype();
			}
			if (wordLine.getId() == targetInd)
				// if head not in stopWords: --> do not implement stop words
				deps.add(String.join("I_", relation, head));
			else
				// if word_line.form not in stopWords: --> do not implement stop words
				deps.add(String.join("_", relation, wordLine.getForm()));
		}
		return deps;
	}
	
	public static String vec2Str(List<Map.Entry<String, Float>> resultVec, int maxNum) {
		List<String> subStrs = resultVec.stream()
				.sorted((e1, e2) -> (int) (e2.getValue() - e1.getValue())).limit(maxNum)
				.map((Map.Entry<String, Float> e) -> (e.getKey() + " " + String.format("%.5f", e.getValue())))
				.collect(Collectors.toCollection(LinkedList::new));
		return String.join("\t", subStrs);
	}
	
	public static String vec2StrGenerated(List<Map.Entry<String, Float>> resultVec, int maxNum) {
		List<String> subStrs = resultVec.stream()
				.sorted((e1, e2) -> (int) (e2.getValue() - e1.getValue())).limit(maxNum)
				.map(Map.Entry::getKey).collect(Collectors.toCollection(LinkedList::new));
		return String.join(";", subStrs);
	}

}
